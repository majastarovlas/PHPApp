<?php
include '../db.php';
$id=$_GET['id'];
  $sql = "DELETE FROM poslovi WHERE posaoid=$id";
  if ($conn->query($sql) === TRUE) {
  echo "<script type='text/javascript'>alert('Uspešno ste izbrisali posao.');</script>";
  ?>
    <script>
        window.location.href='poslovi.php';
    </script>   
  <?php
} else {
  echo "<script type='text/javascript'>alert('Greška!!! Pokušajte ponovo.');</script>";
  ?>
    <script>
        window.location.href='poslovi.php';
    </script>   
  <?php
}
?>