<?php
session_start();
include '../db.php';
$sql = "SELECT * from kompanija_info where kompanijaid=1;";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$info = $row['oKompaniji'];
$ret = str_replace("<br /><br />", "", $info);
$ret1 = str_replace("<br />", "", $ret);
if(isset($_SESSION)&& !empty($_SESSION)){
  $userid=$_SESSION['posetiocid'];
  $ime = $_SESSION['ime_prezime'];
}
else{
   ?>
<script>
window.location.href='index.php';
</script>
<?php
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Izmeni info o kompaniji</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
 
    <?php include 'leva-strana.php';?>
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Admin panel</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="informacije.php">Naslovna</a></li>
                                <li><span>Informacije</span></li>
                            </ul>
                        </div>
                    </div>
                   <?php include 'desna-strana.php';?>
                </div>
            </div>
          
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-3 col-ml-12"></div>
                    <div class="col-lg-6 col-ml-12">
                        <div class="row">
                            <!-- Textual inputs start -->
                            <div class="col-12 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Forma za izmenu informacija o kompaniji</h4>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Naziv kompanije</label>
                                            <input class="form-control" type="text" value="<?php echo $row['nazivKompanije'];?>" id="naziv">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Email</label>
                                            <input class="form-control" type="text" value="<?php echo $row['email'];?>" id="email">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Adresaa</label>
                                            <input class="form-control" type="text" value="<?php echo $row['adresa'];?>" id="adresa">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Telefon</label>
                                            <input class="form-control" type="text" value="<?php echo $row['telefon'];?>" id="telefon">
                                        </div>
                                         <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Radno vreme</label>
                                            <input class="form-control" type="text" value="<?php echo $row['radnoVreme'];?>" id="radnoVreme">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">O kompaniji</label>
                                            <textarea class="form-control" type="text" rows="15" id="oKompaniji"> <?php echo $ret1;?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <div align="center">
                                                <button type="button" class="btn btn-rounded btn-success mb-3" onclick="izmeniInfo();">Izmeni informacije</button>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                   
                         
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
      
    </div>
   
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="assets/skripte/js/main.js"></script>
</body>

</html>
