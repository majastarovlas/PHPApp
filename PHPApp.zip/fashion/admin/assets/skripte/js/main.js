function pristup(){
    var user = document.getElementById('korisnicko').value;
    var pass = document.getElementById('lozinka').value;
    
    if((user ==="" || user === null || user === undefined) && (pass ==="" || pass === null || pass === undefined)){
      alert("Polja moraju biti popunjena");
    }
    else{
    $.ajax({
    url: "assets/skripte/php/prijava.php",
    type: "POST",
    data:{user:user,pass:pass}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Prijava uspešna");
	window.location.href='proizvodi.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });
    }

}

function prijava(){
    var user = document.getElementById('pass').value;
    var pass = document.getElementById('user').value;
    
    if((user ==="" || user === null || user === undefined) && (pass ==="" || pass === null || pass === undefined)){
      alert("Polja moraju biti popunjena");
    }
    else{
    $.ajax({
    url: "admin/assets/skripte/php/prijava-sajt.php",
    type: "POST",
    data:{user:user,pass:pass}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Prijava uspešna");
	window.location.href='profil.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });
    }

}

function registracija(){
    var user = document.getElementById('pass').value;
    var pass = document.getElementById('user').value;
    var ime = document.getElementById('ime').value;
    var email = document.getElementById('email').value;
    if((user ==="" || user === null || user === undefined) && (pass ==="" || pass === null || pass === undefined)&& (ime ==="" || ime === null || ime === undefined)&& (email ==="" || email === null || email === undefined)){
      alert("Polja moraju biti popunjena");
    }
    else{
        if(emailValidacija(email)){
            $.ajax({
        url: "admin/assets/skripte/php/registracija.php",
        type: "POST",
        data:{user:user,pass:pass,ime:ime,email:email}
        }).done(function(data) {
            console.log(data);
            if (data==="1"){
            alert("Registracija uspešna");
            window.location.href='profil.php';
            }
            else{
            alert("Došlo je do greške. Pokušajte ponovo");
            }
        });
        }
        
        else{
            alert("Email adresa nije ispravna.");
        }
        }
}

function izmeniProfil(){
    var user = document.getElementById('pass').value;
    var pass = document.getElementById('user').value;
    var ime = document.getElementById('ime').value;
    var email = document.getElementById('email').value;
    if((user ==="" || user === null || user === undefined) && (pass ==="" || pass === null || pass === undefined)&& (ime ==="" || ime === null || ime === undefined)&& (email ==="" || email === null || email === undefined)){
      alert("Polja moraju biti popunjena");
    }
    else{
        if(emailValidacija(email)){
            $.ajax({
        url: "admin/assets/skripte/php/izmeni.php",
        type: "POST",
        data:{user:user,pass:pass,ime:ime,email:email}
        }).done(function(data) {
            console.log(data);
            if (data==="1"){
            alert("Registracija uspešna");
            window.location.href='profil.php';
            }
            else{
            alert("Došlo je do greške. Pokušajte ponovo");
            }
        });
        }
        
        else{
            alert("Email adresa nije ispravna.");
        }
        }
}

function emailValidacija(email) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

function noviPosao(){
 var pozicija = document.getElementById('pozicija').value;
 var opis = document.getElementById('opis').value;    
    $.ajax({
    url: "assets/skripte/php/novi-posao.php",
    type: "POST",
    data:{pozicija:pozicija,opis:opis}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Uspesno ste dodali posao");
	window.location.href='poslovi.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });
}

function izmeniPosao(id){
 var pozicija = document.getElementById('pozicija').value;
 var opis = document.getElementById('opis').value;    
    $.ajax({
    url: "assets/skripte/php/izmeni-posao.php",
    type: "POST",
    data:{pozicija:pozicija,opis:opis,id:id}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Uspesno ste izmenili posao");
	window.location.href='poslovi.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });
}

function izmeniInfo(){
 var naziv = document.getElementById('naziv').value;
 var email = document.getElementById('email').value;
 var adresa = document.getElementById('adresa').value;
 var radnoVreme = document.getElementById('radnoVreme').value;
 var telefon = document.getElementById('telefon').value;
 var oKompaniji = document.getElementById('oKompaniji').value;
 if(naziv==="" || email==="" || adresa==="" || radnoVreme==="" || telefon==="" || oKompaniji===""){
     
 }
 else{
     if(emailValidacija(email)){
          $.ajax({
    url: "assets/skripte/php/izmeni-info.php",
    type: "POST",
    data:{naziv:naziv,email:email,adresa:adresa,radnoVreme:radnoVreme,oKompaniji:oKompaniji,telefon:telefon}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Uspesno ste izmenili informacije o kompaniji");
	window.location.href='poslovi.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
        });
     }
     else{
         alert("Uneta email adresa nije validna");
     }
    
 }
 
}

function poruka(){
    var tip =0;
    if($('#kritika').is(':checked'))
    {
        tip = 0;
    }
    else{
        tip = 1;
    }
    var email = document.getElementById('email').value;
    var naslov = document.getElementById('naslov').value;
    var telefon = document.getElementById('telefon').value;
    var ime = document.getElementById('ime').value;
    var prezime = document.getElementById('prezime').value;
    var poruka = document.getElementById('poruka').value;
    if(ime === "" || poruka=== "" ||  prezime=== "" || telefon=== "" || naslov=== "" || email=== ""){
      alert("Polja moraju biti popunjena");
    }
    else{
          if(emailValidacija(email)){
    $.ajax({
    url: "admin/assets/skripte/php/poruka.php",
    type: "POST",
    data:{email:email,naslov:naslov,telefon:telefon,ime:ime,prezime:prezime,poruka:poruka,tip:tip}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Poruka poslata");
	window.location.href='kontakt.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });
    }
    else{
         alert("Email nije validan");
    }
    }
}

function konkurisi(id,uid){
   
    var iskustvo = document.getElementById('iskustvo').value;
    
    $.ajax({
    url: "admin/assets/skripte/php/konkurs.php",
    type: "POST",
    data:{iskustvo:iskustvo,id:id,uid:uid}
    }).done(function(data) {
        console.log(data);
        if (data==="1"){
        alert("Uspesno ste konkurisali za posao");
	window.location.href='index.php';
        }
        else{
        alert("Došlo je do greške. Pokušajte ponovo");
        }
    });

}