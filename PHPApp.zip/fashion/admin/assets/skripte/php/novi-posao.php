<?php
session_start();
include '../../../../db.php';
if(isset($_POST['pozicija']))
{

    $pozicija = $_POST['pozicija'];
    $opis=$_POST['opis'];
    
     $sql = "INSERT INTO  poslovi (posao,opis) VALUES ('$pozicija', '$opis')";
    
     if ($conn->query($sql) === TRUE) {
        echo "1";
     }
     else{
        echo $sql;
     }
}
?>