<?php
session_start();
include '../../../../db.php';
if(isset($_POST['email']))
{

    $email = $_POST['email'];
    $ime=$_POST['ime'];
    $pass =md5($_POST['pass']);
    $user = $_POST['user'];
   
     $sql = "INSERT INTO  posetioci (ime_prezime,email, korisnicko, lozinka) VALUES ('$ime', '$email','$user', '$pass')";
    
     if ($conn->query($sql) === TRUE) {
        echo "1";
     }
     else{
        echo $sql;
     }
}
?>