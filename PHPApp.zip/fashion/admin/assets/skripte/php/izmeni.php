<?php
session_start();
include '../../../../db.php';
if(isset($_POST['email']))
{

     $korisnicko = $_POST['user'];
    $email = $_POST['email'];
    $ime=$_POST['ime'];
    $pass =md5($_POST['pass']);
    if($pass===""){
        $sql = "UPDATE posetioci set ime_prezime='$ime',email='$email' where korisnicko='$korisnicko'";
    }
    else{
       $sql = "UPDATE posetioci set ime_prezime='$ime',email='$email', lozinka='$pass' where korisnicko='$korisnicko'";
    }
   
     
    
     if ($conn->query($sql) === TRUE) {
        echo "1";
     }
     else{
        echo $sql;
     }
}
?>