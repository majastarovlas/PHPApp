<?php
session_start();
include '../../../../db.php';
if(isset($_POST['iskustvo']))
{

    $iskustvo = $_POST['iskustvo'];
    $id=$_POST['id'];
    $uid =$_POST['uid'];

     $sql = "INSERT INTO  karijera (idkorisnik,idposao,iskustvo) VALUES ('$uid', '$id','$iskustvo')";
    
     if ($conn->query($sql) === TRUE) {
        echo "1";
     }
     else{
        echo $sql;
     }
}
?>