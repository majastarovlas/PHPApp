<?php
session_start();
include '../../../../db.php';
if(isset($_POST['user']))
{

            $user = $_POST['user'];	
            $password =md5($_POST['pass']);
            $query = "SELECT * FROM `posetioci` WHERE korisnicko='$user' and lozinka='$password' and rola=1";
            $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
            $count = mysqli_num_rows($result);
            if ($count == 1)
            {       
                while($row = mysqli_fetch_array($result))
                {
                    $_SESSION['posetiocid'] = $row['posetiocid'];
                    $_SESSION['korisnicko'] = $row['korisnicko'];
                    $_SESSION['ime_prezime']= $row['ime_prezime'];
                }
                echo "1";
            }
            else{
                echo "0";
            }
}
?>