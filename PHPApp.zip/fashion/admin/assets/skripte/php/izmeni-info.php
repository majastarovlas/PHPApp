<?php
session_start();
include '../../../../db.php';
if(isset($_POST['oKompaniji']))
{
    $oKompaniji = $_POST['oKompaniji'];
    $naziv=$_POST['naziv'];
    $email=$_POST['email'];
    $adresa=$_POST['adresa'];
    $telefon=$_POST['telefon'];
    $radnoVreme=$_POST['radnoVreme'];
    
	 $nv = nl2br($oKompaniji);
    $sql = "UPDATE kompanija_info set nazivKompanije='$naziv',email='$email', telefon='$telefon', adresa='$adresa', radnoVreme='$radnoVreme', oKompaniji='$nv' where kompanijaid=1";
    if ($conn->query($sql) === TRUE) {
        echo "1";
    }
    else{
        echo $sql;
    }
}
?>