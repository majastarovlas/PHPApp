<?php
session_start();
include '../../../../db.php';
if(isset($_POST['pozicija']))
{
    $pozicija = $_POST['pozicija'];
    $opis=$_POST['opis'];
    $id=$_POST['id'];
    $sql = "UPDATE poslovi set posao='$pozicija',opis='$opis' where posaoid=$id";
    if ($conn->query($sql) === TRUE) {
        echo "1";
    }
    else{
        echo $sql;
    }
}
?>