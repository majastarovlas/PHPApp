<?php
session_start();
include '../../../../db.php';
if(isset($_POST['email']))
{

    $email = $_POST['email'];
    $ime=$_POST['ime'];
    $prezime =$_POST['prezime'];
    $naslov =$_POST['naslov'];
    $poruka = $_POST['poruka'];
     $tip = $_POST['tip'];
      $telefon = $_POST['telefon'];
     $sql = "INSERT INTO  kontakt (ime,prezime,telefon,email, naslov, poruka, tip) VALUES ('$ime', '$prezime','$telefon', '$email','$naslov','$poruka','$tip')";
    
     if ($conn->query($sql) === TRUE) {
        echo "1";
     }
     else{
        echo $sql;
     }
}
?>