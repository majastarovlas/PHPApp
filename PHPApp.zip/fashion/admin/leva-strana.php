
    <div class="page-container">
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="proizvodi.php"><img src="../slike/logo.png" width="50%;" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li><a href="informacije.php"><i class="ti-map-alt"></i> <span>MS Fashion</span></a></li>
                            <li><a href="proizvodi.php"><i class="ti-receipt"></i> <span>Proizvodi</span></a></li>
                            <li><a href="poslovi.php"><i class="ti-map-alt"></i> <span>Poslovi</span></a></li>
                            <li><a href="korisnici.php"><i class="ti-receipt"></i> <span>Registrovani članovi</span></a></li>
                             <li><a href="vesti.php"><i class="ti-receipt"></i> <span>Vesti</span></a></li>
                            <li><a href="poruke.php"><i class="ti-map-alt"></i> <span>Poruke</span></a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
     
<div class="main-content">
            <div class="header-area">
                <div class="row align-items-center">
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                      
                    </div>
                </div>
</div>