<?php
session_start();
include '../db.php';
if(isset($_SESSION)&& !empty($_SESSION)){
  $userid=$_SESSION['posetiocid'];
  $ime = $_SESSION['ime_prezime'];
}
else{
   ?>
<script>
window.location.href='index.php';
</script>
<?php
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dodaj proizvod</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
 
    <?php include 'leva-strana.php';?>
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.html">Home</a></li>
                                <li><span>Form</span></li>
                            </ul>
                        </div>
                    </div>
                   <?php include 'desna-strana.php';?>
                </div>
            </div>
          
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-3 col-ml-12"></div>
                    <div class="col-lg-6 col-ml-12">
                        <div class="row">
                            <!-- Textual inputs start -->
                            <div class="col-12 mt-5">
                                  <form  enctype="multipart/form-data" method="POST">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Forma za dodavanje novog proizvoda</h4>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Naziv</label>
                                            <input class="form-control" type="text"  name="naziv">
                                        </div>
                                       <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Cena</label>
                                            <input class="form-control" type="number"  name="cena">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Dostupne boje</label>
                                            <input class="form-control" type="text"  name="boje">
                                        </div>
                                        <div class="form-group">
                                            <label for="example-text-input" class="col-form-label">Slika</label>
                                           <input class="form-control" type="file" name="image"  id="naslov">
                                        </div>
                                        <div class="form-group">
                                            <div align="center">
                                                <button type="submit" name="submit" class="btn btn-rounded btn-success mb-3">Dodaj proizvod</button>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                  </form>
                            </div>
                   
                         
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
      
    </div>
   
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="assets/skripte/js/main.js"></script>
</body>

</html>
<?php
if(isset($_POST['submit'])){
$naziv = $_POST['naziv'];
$cena = $_POST['cena'];
$boje = $_POST['boje'];
if (!isset($_FILES['image']['tmp_name'])) 
    {
		 
      ?>
          <script type="text/javascript">
			 alert('Uneti fajl nije slika.!');
          </script>
        <?php
    }
   else
    {
      $file=$_FILES['image']['tmp_name'];
      $image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
      $image_name= addslashes($_FILES['image']['name']);
      $image_size= getimagesize($_FILES['image']['tmp_name']);

    
      if ($image_size==FALSE) {
      
        ?>
          <script type="text/javascript">
              alert('Došlo je do greške. Pokušajte ponovo.!');
        
          </script>
        <?php
        }
        
      else{
        
        move_uploaded_file($_FILES["image"]["tmp_name"],"../slike/". $_FILES["image"]["name"]);
        
       $location=$_FILES["image"]["name"];
       $q = "INSERT INTO proizvodi (nazivProizvoda, cena,dostupneBoje, slika) VALUES('$naziv', '$cena', '$boje', '$location')";
       mysqli_query($conn, $q);
       echo $q;
        ?>
      <script type="text/javascript">
    alert('Uspešno ste dodali novi proizvod!');
    window.location.href='proizvodi.php';
          </script>
        <?php
        }
    }
}
?>