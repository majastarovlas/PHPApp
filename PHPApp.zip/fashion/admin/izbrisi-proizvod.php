<?php
include '../db.php';
$id=$_GET['id'];
  $sql = "DELETE FROM proizvodi WHERE proizvodid=$id";
  if ($conn->query($sql) === TRUE) {
  echo "<script type='text/javascript'>alert('Uspešno ste izbrisali proizvod.');</script>";
  ?>
    <script>
        window.location.href='proizvodi.php';
    </script>   
  <?php
} else {
  echo "<script type='text/javascript'>alert('Greška!!! Pokušajte ponovo.');</script>";
  ?>
    <script>
        window.location.href='proizvodi.php';
    </script>   
  <?php
}
?>