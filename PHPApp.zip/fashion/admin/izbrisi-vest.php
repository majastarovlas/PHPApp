<?php
include '../db.php';
$id=$_GET['id'];
  $sql = "DELETE FROM vesti WHERE vestid=$id";
  if ($conn->query($sql) === TRUE) {
  echo "<script type='text/javascript'>alert('Uspešno ste izbrisali vest.');</script>";
  ?>
    <script>
        window.location.href='poslovi.php';
    </script>   
  <?php
} else {
  echo "<script type='text/javascript'>alert('Greška!!! Pokušajte ponovo.');</script>";
  ?>
    <script>
        window.location.href='vesti.php';
    </script>   
  <?php
}
?>