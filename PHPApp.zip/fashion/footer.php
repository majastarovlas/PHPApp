	<section class="footer-top-section home-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-8 col-sm-12">
					<div class="footer-widget about-widget">
                                            <img src="slike/logo.png" width="50%" class="footer-logo" alt="">
					
					</div>
				</div>
				
				
				<div class="col-lg-7 col-md-4 col-sm-6">
                                    <p><?php echo $row['oKompaniji'];?> </p>
				</div>
                            
				<div class="col-lg-2 col-md-4 col-sm-6">
					<div class="footer-widget">
						
						<div class="text-box">
							<p><?php echo $row['nazivKompanije'];?> </p>
							<p><?php echo $row['adresa'];?> </p>
							<p><?php echo $row['telefon'];?></p>
							<p><?php echo $row['email'];?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>