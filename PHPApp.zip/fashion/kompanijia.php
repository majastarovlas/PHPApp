<?php
session_start();
include 'db.php';

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>O kompaniji</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


</head>
<body>
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<?php include 'header1.php'; ?>

	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> / 
				<a href="">Informacije o kompaniji</a> 
				
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
     
	<div class="page-area product-page spad">
               <h1 align='center'>O kompaniji</h1>
		<div class="container">
		
			<div class="product-details">
				<div class="row">
					<div class="col-lg-10 offset-lg-1">
						
						<div class="tab-content">
							<!-- single tab content -->
							<div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
								<p style='color: black; font-size: 20px;'><?php echo $row['oKompaniji'];?></p>
                                                                <p style='color: black; font-size: 20px;'>Adresa: <span style='color:purple;'><?php echo $row['adresa'];?></span></p>
                                                                <p style='color: black; font-size: 20px;'>Telefon: <span style='color:purple;'><?php echo $row['telefon'];?></span></p>
                                                                <p style='color: black; font-size: 20px;'>Email: <span style='color:purple;'><?php echo $row['email'];?></span></p>
                                                                <p style='color: black; font-size: 20px;'>Radno vreme: <span style='color:purple;'><?php echo $row['radnoVreme'];?></span></p>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		
		
		</div>
	</div> 
        <?php include 'footer.php';?>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>