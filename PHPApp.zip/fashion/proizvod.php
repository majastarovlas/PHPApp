<?php
session_start();
include 'db.php';
$id = $_GET['id'];
$sqlGet = "SELECT * from proizvodi where proizvodid=$id";
$resultGet = $conn->query($sqlGet);
$row = $resultGet->fetch_assoc();
$slika = $row['slika'];
$cena = $row['cena'];
$naziv = $row['nazivProizvoda'];
$boje = $row['dostupneBoje'];
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Proizvod</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<?php include 'header1.php';?>
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> / 
				<span>Proizvod</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>

	<div class="page-area product-page spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<figure>
                                            <img class="product-big-img" src="slike/<?php echo $slika;?>" alt="">
					</figure>
					
				</div>
				<div class="col-lg-6">
					<div class="product-content">
						<h2>Haljina: <?php echo $naziv;?></h2>
						<div class="pc-meta">
                                                    <h4 class="price">Cena: <?php echo $cena;?> dinara</h4><br>
							<div class="review">
								<div class="rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star is-fade"></i>
								</div>
								
							</div>
                                                      
						</div>
                                                <h4>Dostupne boje: <?php echo $boje;?></h4><br>
						<a href="#" class="site-btn btn-line">DODAJ</a>
					</div>
				</div>
			</div>

		</div>
	</div> 
	<?php include 'footer.php';?>

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>