<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Vesti</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<div id="preloder">
		<div class="loader"></div>
	</div>
	<?php include 'header1.php';?>
	
	
	<div class="featured-section spad">
		<div class="container">
			<div class="row">
                              <?php
                              $i=0;
                               $sql1 = "SELECT * from vesti";
                                 $result1 = mysqli_query($conn, $sql1);
                                  while($row1 = mysqli_fetch_array($result1))
                                   {
                                   ?>
				<div class="col-lg-6">
                                    <a href="vest.php?id=<?php echo $row1['vestid'];?>"> <h3><?php echo $row1['naslov'];?></h3></a>
					<div class="featured-item">
                                            <a href="vest.php?id=<?php echo $row1['vestid'];?>"><img src="slike/<?php echo $row1['slika'];?>" height="350px;" alt=""></a>
						<a href="vest.php?id=<?php echo $row1['vestid'];?>" class="site-btn">Pročitaj</a>
					</div>
                                     <?php
                            $i++;
                                   if($i%2==0){
                                   ?>
                            <br><br>
                            <?php
                                   }
                                   ?>
				</div>
                           
                                   <?php
                                   }
                            ?>
				
			</div>
		</div>
	</div>
	
	<?php include 'footer.php';?>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>