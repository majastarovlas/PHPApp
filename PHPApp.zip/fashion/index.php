<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>MS FASHION</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	
	
        <?php include 'header.php';?>

	<section class="hero-section set-bg" data-setbg="img/bg.jpg">
		<div class="hero-slider owl-carousel">
			<div class="hs-item">
				<div class="hs-left"><img src="img/slider-img.png" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						<div class="price">Već od 2500 dinara</div>
						<h2><span>2020</span> <br>Letnja kolekcija</h2>
						
					</div>	
				</div>
			</div>
			<div class="hs-item">
                            <div class="hs-left"><img src="img/f21.jpg" alt=""></div>
				<div class="hs-right">
					
				</div>
			</div>
                        <div class="hs-item">
                            <div class="hs-left"><img src="slike/haljina1.jpg" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						
					</div>	
				</div>
			</div>
                        <div class="hs-item">
                            <div class="hs-left"><img src="slike/haljina2.jpg" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						
					</div>	
				</div>
			</div>
                    <div class="hs-item">
                            <div class="hs-left"><img src="slike/haljina3.jpg" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						
					</div>	
				</div>
			</div>
                    <div class="hs-item">
                            <div class="hs-left"><img src="slike/haljina4.jpg" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						
					</div>	
				</div>
			</div>
                    <div class="hs-item">
                            <div class="hs-left"><img src="slike/haljina5.jpg" alt=""></div>
				<div class="hs-right">
					<div class="hs-content">
						
					</div>	
				</div>
			</div>
		</div>
	</section>

	
	<section class="product-section spad">
		<div class="container">
			<ul class="product-filter controls">
				<li class="control" data-filter=".new">Najnovije</li>
				<li class="control" data-filter="all">Preporučujemo</li>
				<li class="control" data-filter=".best">Najprodavanije</li>
			</ul>
			<div class="row" id="product-filter">
				<div class="mix col-lg-3 col-md-6 best">
					<div class="product-item">
						<figure>
                                                    <img src="slike/haljina3.jpg" height="400px" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									<img src="img/icons/eye.png" alt="">
									<p>quick view</p>
								</div>
								<div class="pi-m-right">
									<img src="img/icons/heart.png" alt="">
									<p>save</p>
								</div>
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 new">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina2.jpg" height="400px" alt="">
							<div class="bache">Novo</div>
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 best">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina1.jpg" height="400px" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									
										 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 new best">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina5.jpg" height="400px" alt="">
							<div class="bache sale">Rasprodaja</div>
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 best">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina4.jpg" height="400px" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 new">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina3.jpg" height="400px" alt="">
							<div class="bache">Novo</div>
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 best">
					<div class="product-item">
						<figure>
							   <img src="slike/haljina2.jpg" height="400px" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
				<div class="mix col-lg-3 col-md-6 best">
					<div class="product-item">
						<figure>
                                                    <img src="slike/haljina1.jpg" height="400px" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
								
							</div>
						</figure>
						
					</div>
				</div>
			</div>
		</div>
	</section>

        <?php include 'footer.php';?>
	

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>