<?php
session_start();
include 'db.php';

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Karijera</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<div id="preloder">
		<div class="loader"></div>
	</div>
	<?php include 'header1.php' ;?>
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> / 
				<a href="">Karijera</a> 
				
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>

	<!-- Page -->
	<div class="page-area cart-page spad">
		<div class="container">
			<div class="cart-table">
				<table>
					<thead>
						<tr>
							<th class="product-th">Pozicija</th>
							<th>Pogledaj detaljnije</th>
							
						</tr>
					</thead>
                                        
					<tbody>
                                               <?php
                                             $sqlPR1 = "SELECT * from poslovi";
                                                $resultPR1 = mysqli_query($conn, $sqlPR1);
                                                while($rowPR1 = mysqli_fetch_array($resultPR1))
                                                {
                                              
                                            ?>
						<tr>
							<td class="product-col">
                                                            <img src="slike/karijera.jfif" alt="">
								<div class="pc-title">
									<h4><?php echo $rowPR1['posao'];?></h4>
									
								</div>
							</td>
							
							 <?php if(isset($_SESSION)&& !empty($_SESSION)){
                                                             $link = "pogledaj-posao.php?id=".$rowPR1['posaoid'];
                                                         }
                                                         else{
                                                            $link = "registracija.php";
                                                         }
                                                         ?>   
                                                         
                                                        <td><a href='<?php echo $link;?>'><i class='fa fa-search-plus fa-3x' title="Samo registrovani korisnici mogu da konkurisu!"></i>'</a></td>
						</tr>
                                                <?php
                                                }
                                                ?>
					</tbody>
				</table>
			</div>
			
		</div>
	
	</div>
        <?php include 'footer.php';?>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>