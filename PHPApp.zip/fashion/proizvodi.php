<?php
session_start();
include 'db.php';?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Haljine</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">  
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


</head>
<body>
	<?php include 'header1.php';?>
	
    <div class="page-info-section page-info-big">
		<div class="container">
			<h2>Haljine</h2>
			<div class="site-breadcrumb">
                            <a href="index.php">Naslovna</a> / 
				<span>Naslovna</span>
			</div>
			<img src="img/categorie-page-top.png" alt="" class="cata-top-pic">
		</div>
	</div>
	<!-- Page Info end -->


	<!-- Page -->
	<div class="page-area categorie-page spad">
		<div class="container">
		
			<div class="row">
                              <?php
                               $sqlPR1 = "SELECT proizvodid, nazivProizvoda,cena,slika from proizvodi";
                                 $resultPR1 = mysqli_query($conn, $sqlPR1);
                                  while($row = mysqli_fetch_array($resultPR1))
                                   {
                                  
                                   ?>
				<div class="col-lg-3">
					<div class="product-item">
						<figure>
                                                    <img src="slike/<?php echo $row['slika'];?>" height="400px;" alt="">
							<div class="pi-meta">
								<div class="pi-m-left">
									 <a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><img src="img/icons/eye.png"  alt="">
                                                                       <p><span style="color: white;"> Pogledaj</span> </p></a>
								</div>
							</div>
						</figure>
						<div class="product-info">
                                                    <h6><a href="proizvod.php?id=<?php echo $row['proizvodid'];?>"><span style="color:black"><?php echo $row['nazivProizvoda'];?></span></a></h6>
							<p><?php echo $row['cena'];?> din.</p>
							
						</div>
					</div>
				</div>
                            <?php
                            }
                            ?>
			</div>
			<div class="site-pagination">
				<span class="active">01.</span>
				<a href="">02.</a>
				<a href="">03.</a>
				<a href="">04.</a>
				<a href="">05.</a>
				<a href="">06</a>
			</div>
		</div>
	</div>
        <?php
        include 'footer.php';
        ?>
        

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>