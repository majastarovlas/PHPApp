<?php
session_start();
include 'db.php';

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Kontakt</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<!-- Page Preloder -->
	
        <?php include 'header1.php';?>

	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> /
				<span>Kontakt</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
	<!-- Page Info end -->


	<!-- Page -->
	<div class="page-area contact-page">
		<div class="container spad">
			<div class="text-center">
				<h4 class="contact-title">Kontakt forma</h4>
			</div>
			<div class="contact-form">
				<div class="row">
					<div class="col-md-6">
						<input type="text" id='ime' placeholder="Ime... *"> 
					</div>
					<div class="col-md-6">
						<input type="text" id='prezime' placeholder="Prezime *"> 
					</div>
                                        <div class="col-md-6">
						<input type="email" id='email' placeholder="Email... *"> 
					</div>
					<div class="col-md-6">
						<input type="text" id='telefon' placeholder="Telefon*"> 
					</div>
					<div class="col-md-12">
                                           
							<input type="text" id='naslov' placeholder="Naslov poruke *"> 
						<textarea placeholder="Poruka" id="poruka"></textarea>
                                                 <input type="radio"  class="radio" name="tip" checked id='kritika' > Kritika <input type="radio" class="radio"  name="tip" id='predlog' > Predlog
						<div class="text-center">
							<button class="site-btn" style='background-color: #aa7ad0' onclick="poruka();">Pošalji poruku</button>
						</div>
                                                
					</div>
                                    
				</div>
			</div>
                </div><br><br><br><br><br><br><br>
		<div class="container contact-info-warp">
			<div class="contact-card">
				<div class="contact-info">
					<h4>Naše informacije</h4>
					<p>Phone:    +53 345 7953 32453</p>
					<p>Email:   yourmail@gmail.com</p>
				</div>
				
			</div>
		</div>
		<div class="map-area">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2829.973221531018!2d20.45303491553608!3d44.82211017909859!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a654bb308bd05%3A0xd6c940512165fd08!2zVGFkZXXFoWEgS2_FocSHdcWha2EgMTMsIEJlb2dyYWQ!5e0!3m2!1sen!2srs!4v1591211983031!5m2!1sen!2srs" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
		</div>
	</div> 
        <?php include 'footer.php';?>

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
        <script src="admin/assets/skripte/js/main.js"></script>

    </body>
</html>