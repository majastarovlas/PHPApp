<?php
session_start();
include 'db.php';

if(isset($_SESSION)&& !empty($_SESSION)){
 
    $id=$_GET['id'];
    $sql2 = "SELECT * from poslovi where posaoid=$id;";
    $result2 = $conn->query($sql2);
    $row2 = $result2->fetch_assoc();
    $uid = $_SESSION['posetiocid'];
}
else{
   ?>
<script>
window.location.href='index.php';
</script>
<?php
}
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Vesti</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<?php include 'header1.php'; ?>

	<!-- Page Info -->
	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> / 
				<a href="">Posao</a> 
				
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>
     
	<div class="page-area product-page spad">
             
             
               
                <h1 align='center'><?php echo $row2['posao'];?></h1>
		<div class="container">
		   
			<div class="product-details">
				<div class="row">
					<div class="col-lg-10 offset-lg-1">
						
						<div class="tab-content">
							
							<div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
                                                        
								<p style='color: black; font-size: 20px;'><?php echo $row2['opis'];?></p>
                                                              
							</div>
							
						</div>
					</div>
				</div>
			</div>
                        <div class="contact-form">
				<div class="row">
					<div class="col-md-12">
						<textarea placeholder="Unesi radno iskustvo" id="iskustvo"></textarea>
						<div class="text-center">
							<button class="site-btn" style='background-color: #aa7ad0' onclick="konkurisi(<?php echo $id;?>, <?php echo $uid;?>);">Konkuriši</button>
						</div>
					</div>
                                    
				</div>
			</div>
		</div>
	</div> 
        <?php include 'footer.php';?>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
        <script src="admin/assets/skripte/js/main.js"></script>
    </body>
</html>