-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2020 at 07:00 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ms_fashion`
--

-- --------------------------------------------------------

--
-- Table structure for table `karijera`
--

CREATE TABLE `karijera` (
  `karijeraid` int(11) NOT NULL,
  `idkorisnik` int(25) DEFAULT NULL,
  `idposao` int(11) DEFAULT NULL,
  `iskustvo` varchar(150) DEFAULT NULL,
  `datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `karijera`
--

INSERT INTO `karijera` (`karijeraid`, `idkorisnik`, `idposao`, `iskustvo`, `datum`) VALUES
(1, 1, 1, 'Bez iskustva', '2020-06-05 15:28:31'),
(2, 5, 1, 'proba123', '2020-06-07 10:31:42');

-- --------------------------------------------------------

--
-- Table structure for table `kompanija_info`
--

CREATE TABLE `kompanija_info` (
  `kompanijaid` int(11) NOT NULL,
  `nazivKompanije` varchar(100) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `adresa` varchar(250) DEFAULT NULL,
  `telefon` varchar(100) DEFAULT NULL,
  `radnoVreme` varchar(50) DEFAULT NULL,
  `oKompaniji` varchar(1200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kompanija_info`
--

INSERT INTO `kompanija_info` (`kompanijaid`, `nazivKompanije`, `email`, `adresa`, `telefon`, `radnoVreme`, `oKompaniji`) VALUES
(1, 'MS Fashion', 'starovlasmaja@gmail.com', 'TadeuÅ¡a KoÅ¡Ä‡uÅ¡ka 13 Beograd', '+38160222431', '08:00 - 20:00', '  MS Fashion kreira, proizvodi i prodaje sirom sveta rucno sivene haljine od visokokvalitetnih materijala. Posvecivanjem posebne paznje rucnom radu i svakom detalju, MS Fashion nastoji da omoguci svojim klijentima visok kvalitet i eleganciju za pristupacnu cenu.<br />\n<br />\nOsnovan je kao mala radionica pre skoro deceniju od strane kreatorke Marije Stojanovic koja dizajnira sve modele. U toploj porodicnoj atmosferi radjale su se ideje i magija je stvorena. Elegantne haljine nizale su se jedna za drugom postepeno osvajajuci srca dama. Posle nekoliko godina, mala radionica razvila se u moderan studio u centru srpske prestonice. Danas zaposljava preko dvadeset visokokvalifikovanih snajderki sa konstantnom tendencijom sirenja poslovanja. Sa sedistem u Beogradu, MS Fashion posluje i u Novom Sadu, kao i preko interneta.');

-- --------------------------------------------------------

--
-- Table structure for table `kontakt`
--

CREATE TABLE `kontakt` (
  `kontaktid` int(11) NOT NULL,
  `ime` varchar(20) DEFAULT NULL,
  `prezime` varchar(20) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `naslov` varchar(200) DEFAULT NULL,
  `poruka` varchar(1500) DEFAULT NULL,
  `tip` int(11) DEFAULT NULL,
  `datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kontakt`
--

INSERT INTO `kontakt` (`kontaktid`, `ime`, `prezime`, `email`, `telefon`, `naslov`, `poruka`, `tip`, `datum`) VALUES
(1, 'proba', 'proba', 'marko@gmail.com', '123456789', 'proba', 'proba123', 0, '2020-06-05 11:28:54'),
(2, '123', '123', '1@gmail.com', '32', '32', '32131', 1, '2020-06-07 10:16:37');

-- --------------------------------------------------------

--
-- Table structure for table `posetioci`
--

CREATE TABLE `posetioci` (
  `posetiocid` int(11) NOT NULL,
  `ime_prezime` varchar(75) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `korisnicko` varchar(20) DEFAULT NULL,
  `lozinka` varchar(100) DEFAULT NULL,
  `datumRegistracije` datetime DEFAULT current_timestamp(),
  `rola` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posetioci`
--

INSERT INTO `posetioci` (`posetiocid`, `ime_prezime`, `email`, `korisnicko`, `lozinka`, `datumRegistracije`, `rola`) VALUES
(1, 'Marko', 'marko@gmail.com', 'marko', '202cb962ac59075b964b07152d234b70', '2020-06-05 11:22:40', 1),
(4, 'maja123', 'maja123@gmail.com', 'maja', '827ccb0eea8a706c4c34a16891f84e7b', '2020-06-06 18:45:56', 0),
(5, 'Marko', 'marko.b@gmail.com', 'mare', '202cb962ac59075b964b07152d234b70', '2020-06-07 09:14:54', 0);

-- --------------------------------------------------------

--
-- Table structure for table `poslovi`
--

CREATE TABLE `poslovi` (
  `posaoid` int(11) NOT NULL,
  `posao` varchar(150) DEFAULT NULL,
  `opis` varchar(1500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `poslovi`
--

INSERT INTO `poslovi` (`posaoid`, `posao`, `opis`) VALUES
(1, 'Potrebna osoba za rad u butiku(m/ž)!', 'Trgovac sa iskustvom, potreban renomiranom butiku na Novom Beogradu. Radno vreme: -6 dana,40 sati nedeljno Jedan slobodan dan po dogovoru, Potrazujemo: -vredne,odgovorne -spremne za timski rad.'),
(2, 'Potreban web dizajner!', 'Tražimo dizajnera sa sposobnostima kreiranja 3D i grafickog dizajna. Rad u 3D MAX-u ja obavezan. Biografiju i portfolio poslati na msfashion@gmail.com Rok za prijavu je 31. jun 2020.'),
(3, 'Potrebna kreatorka sa iskustvom!', 'Trazimo mladu kreativnu devojku sa iskustvom i voljom za rad u butiku sa mnogim mogucnostima napredovanja. Plata po dogovoru.'),
(6, '123456', '141');

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

CREATE TABLE `proizvodi` (
  `proizvodid` int(11) NOT NULL,
  `nazivProizvoda` varchar(150) DEFAULT NULL,
  `cena` int(11) DEFAULT NULL,
  `dostupneBoje` varchar(150) DEFAULT NULL,
  `slika` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`proizvodid`, `nazivProizvoda`, `cena`, `dostupneBoje`, `slika`) VALUES
(1, 'Party Dress', 2800, 'Bela, Zelena, Crna, Crvena', 'haljina1.jpg'),
(2, 'Summer Dress', 1800, 'Bela, Zelena, Crna, Zuta', 'haljina2.jpg'),
(3, 'Elegant Short Dress', 2000, 'Zelena, Crvena', 'haljina4.jpg'),
(4, 'Prom Long Dress', 25000, 'Crvena, Crna', 'haljina5.jpg'),
(5, 'Wedding Dress', 2800, 'Bela', 'haljina3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `vesti`
--

CREATE TABLE `vesti` (
  `vestid` int(11) NOT NULL,
  `naslov` varchar(150) DEFAULT NULL,
  `tekst` varchar(5000) DEFAULT NULL,
  `datum` datetime DEFAULT current_timestamp(),
  `slika` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vesti`
--

INSERT INTO `vesti` (`vestid`, `naslov`, `tekst`, `datum`, `slika`) VALUES
(1, 'Nova online prodavnica!', 'Od sada kod nas mozete i iz udobnosti svog doma narucivati svoje omiljene modele haljina. Ceo asortiman ce vam biti dostupan na svim vasim uredjajima i samo jednim klikom mozete izabrati svoju omiljenu haljinu koja ce vam biti dostupna na kucnoj adresi u roku od 48h.', '2020-06-05 11:41:06', 'online.jfif'),
(2, 'Novi lokal na Dorcolu!', 'Od sada mozete nasu prodavnicu naci i u Dusanovoj 15 u jos vecem lokalu. Vidimo se uskoro!', '2020-06-05 11:41:38', 'butik.jpg'),
(4, 'proba1234', '1123', '2020-06-05 15:36:52', '2.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `karijera`
--
ALTER TABLE `karijera`
  ADD PRIMARY KEY (`karijeraid`);

--
-- Indexes for table `kompanija_info`
--
ALTER TABLE `kompanija_info`
  ADD PRIMARY KEY (`kompanijaid`);

--
-- Indexes for table `kontakt`
--
ALTER TABLE `kontakt`
  ADD PRIMARY KEY (`kontaktid`);

--
-- Indexes for table `posetioci`
--
ALTER TABLE `posetioci`
  ADD PRIMARY KEY (`posetiocid`);

--
-- Indexes for table `poslovi`
--
ALTER TABLE `poslovi`
  ADD PRIMARY KEY (`posaoid`);

--
-- Indexes for table `proizvodi`
--
ALTER TABLE `proizvodi`
  ADD PRIMARY KEY (`proizvodid`);

--
-- Indexes for table `vesti`
--
ALTER TABLE `vesti`
  ADD PRIMARY KEY (`vestid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `karijera`
--
ALTER TABLE `karijera`
  MODIFY `karijeraid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `kompanija_info`
--
ALTER TABLE `kompanija_info`
  MODIFY `kompanijaid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kontakt`
--
ALTER TABLE `kontakt`
  MODIFY `kontaktid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `posetioci`
--
ALTER TABLE `posetioci`
  MODIFY `posetiocid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `poslovi`
--
ALTER TABLE `poslovi`
  MODIFY `posaoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `proizvodi`
--
ALTER TABLE `proizvodi`
  MODIFY `proizvodid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vesti`
--
ALTER TABLE `vesti`
  MODIFY `vestid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
