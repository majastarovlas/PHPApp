<?php
$sqlGet = "SELECT * from  kompanija_info where kompanijaid=1";
$resultGet = $conn->query($sqlGet);
$row = $resultGet->fetch_assoc();
?>	
<header class="header-section header-normal">
		<div class="container-fluid">
			<div class="site-logo">
                            <img src="slike/logo.png" alt="logo" width="50%;">
			</div>
                        <div class="header-right">
                             <?php if(isset($_SESSION)&& !empty($_SESSION)){
                                 $korisnicko= $_SESSION['korisnicko'];
                                 ?>
                              
                             <a href="profil.php"><span style='color: white;'><?php echo $korisnicko;?> /</span></a>
			    <a href="odjava.php"><span style='color: white;'>Odjava</span></a>
                            <?php
                             }
                             
                             else{
                                 ?>
                             <a href="prijava.php"><span style='color: white;'>Prijava /</span></a>
			    <a href="registracija.php"><span style='color: white;'>Registracija</span></a>
                             <?php
                             }
                             ?>
				
			</div>    
			<ul class="main-menu">
				<li><a href="index.php">Naslovna</a></li>
				<li><a href="kompanijia.php">O kompaniji</a></li>
				<li><a href="proizvodi.php">Proizvodi</a></li>
				<li><a href="karijera.php">Karijera</a></li>
				<li><a href="kontakt.php">Kontakt</a></li>
                                <li><a href="blog.php">Blog</a></li>
                              
                               
			</ul>
		</div>
	</header>