<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Prijava</title>
	<meta charset="UTF-8">
	<meta name="description" content="The Plaza eCommerce Template">
	<meta name="keywords" content="plaza, eCommerce, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="img/favicon.ico" rel="shortcut icon"/>
	<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
        <?php include 'header1.php';?>

	<div class="page-info-section page-info">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="">Naslovna</a> /
				<span>Kontakt</span>
			</div>
			<img src="img/page-info-art.png" alt="" class="page-info-art">
		</div>
	</div>

	<div class="page-area contact-page">
		<div class="container spad">
			<div class="text-center">
				<h4 class="contact-title">Kontakt forma</h4>
			</div>
			<div class="contact-form">
				<div class="row">
					<div class="col-md-3"></div>
                                     <div class="col-md-6">
                                                <input type="text" id='pass' placeholder="Korisnicko... *"> 
                                     </div>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-3"></div>
					<div class="col-md-6">
						<input type="text" id='user' placeholder="Lozinka *"> 
					</div>
                                      <div class="col-md-3"></div>
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6">
                                            <div class="text-center">
							<button class="site-btn" style='background-color: #aa7ad0' onclick="prijava();">Prijavi se</button>
						</div>
                                        </div>
					
				</div>
			</div>
                </div><br><br><br><br><br><br><br>
	
	
	</div> 
        <?php include 'footer.php';?>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/sly.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
	<script src="js/main.js"></script>
        <script src="admin/assets/skripte/js/main.js"></script>
    </body>
</html>